from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_jwt_extended import (
    JWTManager,
    create_access_token,
    jwt_required,
    get_jwt_identity,
    get_jwt,
)

from config import Config
from models import db, User, Resource


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    JWTManager(app)
    CORS(app, resources={r"/api/*": {"origins": app.config["CORS_ORIGINS"]}})

    with app.app_context():
        db.create_all()

    register_routes(app)
    register_error_handlers(app)
    return app


def register_routes(app):

    # ----- ავტორიზაცია -----

    @app.post("/api/auth/register")
    def register():
        data = request.get_json(silent=True) or {}
        full_name = (data.get("full_name") or "").strip()
        email = (data.get("email") or "").strip().lower()
        password = data.get("password") or ""

        if not full_name or not email or not password:
            return jsonify(error="სახელი, ელფოსტა და პაროლი სავალდებულოა."), 400
        if len(password) < 6:
            return jsonify(error="პაროლი უნდა შეიცავდეს მინიმუმ 6 სიმბოლოს."), 400
        if User.query.filter_by(email=email).first():
            return jsonify(error="ეს ელფოსტა უკვე რეგისტრირებულია."), 409

        user = User(full_name=full_name, email=email, role="student")
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        token = create_access_token(identity=str(user.id), additional_claims={"role": user.role})
        return jsonify(access_token=token, user=user.to_dict()), 201

    @app.post("/api/auth/login")
    def login():
        data = request.get_json(silent=True) or {}
        email = (data.get("email") or "").strip().lower()
        password = data.get("password") or ""

        user = User.query.filter_by(email=email).first()
        if not user or not user.check_password(password):
            # ერთი და იგივე შეცდომას ვწერ ორივე შემთხვევაში (email არასწორია ან პაროლი)
            # რომ არავინ მიხვდეს ზუსტად რომელი email-ია დარეგისტრირებული
            return jsonify(error="ელფოსტა ან პაროლი არასწორია."), 401

        token = create_access_token(identity=str(user.id), additional_claims={"role": user.role})
        return jsonify(access_token=token, user=user.to_dict()), 200

    @app.get("/api/auth/me")
    @jwt_required()
    def me():
        user = User.query.get(int(get_jwt_identity()))
        if not user:
            return jsonify(error="მომხმარებელი ვერ მოიძებნა."), 404
        return jsonify(user=user.to_dict()), 200

    # ----- მასალები -----
    # ფაილების ატვირთვა აღარ არის საჭირო, მხოლოდ ინფორმაციას ვინახავთ
    # მასალაზე (სათაური/საგანი/სემესტრი/ტიპი)

    @app.get("/api/subjects")
    def subjects():
        rows = db.session.query(Resource.subject).distinct().all()
        return jsonify(subjects=sorted({r[0] for r in rows})), 200

    @app.get("/api/resources")
    def list_resources():
        query = request.args.get("q", "").strip().lower()
        subject = request.args.get("subject", "").strip()
        semester = request.args.get("semester", "").strip()

        q = Resource.query
        if subject and subject != "all":
            q = q.filter(Resource.subject == subject)
        if semester:
            q = q.filter(Resource.semester == semester)
        if query:
            q = q.filter(Resource.title.ilike(f"%{query}%"))

        items = q.order_by(Resource.created_at.desc()).all()
        return jsonify(resources=[r.to_dict() for r in items], count=len(items)), 200

    @app.post("/api/resources")
    @jwt_required()
    def add_resource():
        data = request.get_json(silent=True) or {}
        title = (data.get("title") or "").strip()
        subject = (data.get("subject") or "").strip()
        semester = (data.get("semester") or "").strip()
        resource_type = (data.get("resource_type") or "კონსპექტი").strip()

        if not title or not subject or not semester:
            return jsonify(error="სათაური, საგანი და სემესტრი სავალდებულოა."), 400

        resource = Resource(
            title=title,
            subject=subject,
            semester=semester,
            resource_type=resource_type,
            uploader_id=int(get_jwt_identity()),
        )
        db.session.add(resource)
        db.session.commit()

        return jsonify(resource=resource.to_dict()), 201

    @app.delete("/api/resources/<int:resource_id>")
    @jwt_required()
    def delete_resource(resource_id):
        current_user_id = int(get_jwt_identity())
        role = get_jwt().get("role")

        resource = Resource.query.get(resource_id)
        if not resource:
            return jsonify(error="მასალა ვერ მოიძებნა."), 404

        # წაშლა შეუძლია მხოლოდ იმას ვინც დაამატა, ან ადმინს
        if role != "admin" and resource.uploader_id != current_user_id:
            return jsonify(error="წაშლის უფლება არ გაქვს."), 403

        db.session.delete(resource)
        db.session.commit()
        return jsonify(message="მასალა წაიშალა."), 200

    @app.get("/api/health")
    def health():
        # უბრალო route რომ შევამოწმო სერვერი ცოცხალია თუ არა
        return jsonify(status="ok"), 200


def register_error_handlers(app):
    @app.errorhandler(404)
    def not_found(e):
        return jsonify(error="მისამართი ვერ მოიძებნა."), 404

    @app.errorhandler(500)
    def server_error(e):
        return jsonify(error="სერვერზე მოხდა შეცდომა."), 500


app = create_app()

if __name__ == "__main__":
    app.run(debug=True, port=5000)
