"""
სატესტო მონაცემების ჩამტვირთი სკრიპტი.
გავუშვათ ასე: python seed.py

მარტივად ამატებს ერთ ადმინს, ერთ დემო მოსწავლეს და რამდენიმე მასალის
ჩანაწერს, რომ ცარიელ ბაზაზე ვერ ვცადო ლენდინგის გვერდი.
"""
from app import create_app
from models import db, User, Resource

app = create_app()

SAMPLE_RESOURCES = [
    ("კვადრატული განტოლებები", "მათემატიკა", "სემესტრი 1", "კონსპექტი"),
    ("საქართველოს გაერთიანება", "ისტორია", "სემესტრი 2", "დავალება"),
    ("ნიუტონის კანონები", "ფიზიკა", "სემესტრი 1", "კონსპექტი"),
    ("ვეფხისტყაოსანი — ანალიზი", "ქართული", "სემესტრი 2", "დავალება"),
    ("ტრიგონომეტრიის საფუძვლები", "მათემატიკა", "სემესტრი 2", "კონსპექტი"),
    ("XX საუკუნის მოვლენები", "ისტორია", "სემესტრი 1", "კონსპექტი"),
]

with app.app_context():

    if not User.query.filter_by(email="admin@school.edu.ge").first():
        admin = User(full_name="ადმინისტრატორი", email="admin@school.edu.ge", role="admin")
        admin.set_password("admin123")
        db.session.add(admin)

    demo = User.query.filter_by(email="demo@school.edu.ge").first()
    if not demo:
        demo = User(full_name="დემო მოსწავლე", email="demo@school.edu.ge", role="student")
        demo.set_password("demo1234")
        db.session.add(demo)
        db.session.commit()  # commit-ი აქ მჭირდება რომ demo.id ქვემოთ მქონდეს

    if Resource.query.count() == 0:
        for title, subject, semester, rtype in SAMPLE_RESOURCES:
            db.session.add(
                Resource(
                    title=title,
                    subject=subject,
                    semester=semester,
                    resource_type=rtype,
                    uploader_id=demo.id,
                )
            )

    db.session.commit()
    print("სატესტო მონაცემები დაემატა.")
    print("ადმინი:   admin@school.edu.ge / admin123")
    print("მოსწავლე: demo@school.edu.ge / demo1234")
