import os

# ეს ფაილი ინახავს ყველა კონფიგურაციას ერთ ადგილას რომ არ მომიწიოს
# მაგიური სტრიქონების ძებნა app.py-ში ყოველ ჯერზე

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-change-me")
    JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY", "dev-jwt-secret-change-me")
    JWT_ACCESS_TOKEN_EXPIRES = 60 * 60 * 8  # 8 საათი - ვფიქრობ საკმარისია სესიისთვის

    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", "sqlite:///" + os.path.join(BASE_DIR, "platform.db")
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False  # ეს გამორთული უნდა იყოს, warning-ებს იძლევა

    CORS_ORIGINS = os.environ.get("CORS_ORIGINS", "*")
